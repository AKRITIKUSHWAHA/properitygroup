import { useState, useEffect } from 'react';

// Mock data for CRM & Leads
// Lead sources: Website, Referral, Local Surveyors Direct, Email Inquiry, Google Ads, Partner, Expert Witness form
// Tabs / Statuses: All, New, Contacted, Qualified, Quoted, Converted, Lost

export const LEAD_SOURCES = [
  'Website',
  'Local Surveyors Direct',
  'Email Inquiry',
  'Referral',
  'Google Ads',
  'Partner',
  'Expert Witness form',
];

export const LEAD_STATUSES = [
  'New',
  'Contacted',
  'Qualified',
  'Quoted',
  'Converted',
  'Lost',
];

export const INITIAL_LEADS = [
  {
    id: 'LD-1048',
    customerName: 'Harrison Croft',
    customerEmail: 'harrison.croft@example.co.uk',
    customerPhone: '+44 7700 900512',
    enquiry: 'RICS Level 3 Building Survey',
    property: '12 Pembroke Square',
    location: 'Kensington, London W8 6PA',
    source: 'Local Surveyors Direct',
    status: 'New',
    created: '27/10/2026',
    owner: 'Sarah Jenkins',
    estimatedValue: '£1,450.00',
    notes: 'Victorian townhouse built c.1865, basement dampness concerns.',
  },
  {
    id: 'LD-1047',
    customerName: 'Priya Sharma',
    customerEmail: 'priya.s@sharmainvest.com',
    customerPhone: '+44 7700 900891',
    enquiry: 'RICS Level 2 Home Survey',
    property: '45 Park Mansions',
    location: 'Battersea, London SW11 4HG',
    source: 'Website',
    status: 'Contacted',
    created: '27/10/2026',
    owner: 'Alexander Sterling',
    estimatedValue: '£595.00',
    notes: 'First time buyer flat purchase, requested phone call after 5pm.',
  },
  {
    id: 'LD-1046',
    customerName: 'Benjamin & Chloe Vance',
    customerEmail: 'vance.family@ukmail.net',
    customerPhone: '+44 7700 900334',
    enquiry: 'Specific Structural Defect Survey',
    property: '6 The Crescent',
    location: 'Richmond, Surrey TW9 1NR',
    source: 'Referral',
    status: 'Qualified',
    created: '26/10/2026',
    owner: 'David Thorne MRICS',
    estimatedValue: '£850.00',
    notes: 'Mortgage lender raised flag on stepped diagonal cracking in gable wall.',
  },
  {
    id: 'LD-1045',
    customerName: 'Emma Watson',
    customerEmail: 'customer@demo.com',
    customerPhone: '+44 7700 900147',
    enquiry: 'RICS Home Survey - Level 2 (with Valuation)',
    property: '14 Mayfair Gate',
    location: 'Mayfair, London W1K 2PB',
    source: 'Google Ads',
    status: 'Quoted',
    created: '26/10/2026',
    owner: 'Sarah Jenkins',
    estimatedValue: '£650.00',
    notes: 'Formal fee proposal sent, awaiting terms digital signature.',
  },
  {
    id: 'LD-1044',
    customerName: 'Lady Georgina Scott',
    customerEmail: 'g.scott@scottestates.co.uk',
    customerPhone: '+44 20 7946 0912',
    enquiry: 'Historic Building & Valuation Assessment',
    property: '19 Eaton Place',
    location: 'Belgravia, London SW1X 8BN',
    source: 'Partner',
    status: 'Converted',
    created: '25/10/2026',
    owner: 'Alexander Sterling',
    estimatedValue: '£2,800.00',
    notes: 'Referral from Knight Frank Mayfair. Deposit settled.',
  },
  {
    id: 'LD-1043',
    customerName: 'Marcus & Eleanor Bell',
    customerEmail: 'mbell@harrowlaw.co.uk',
    customerPhone: '+44 7700 900219',
    enquiry: 'Part 35 Civil Procedure Expert Witness Report',
    property: '88 St John’s Wood High St',
    location: 'St John’s Wood, London NW8 7SH',
    source: 'Expert Witness form',
    status: 'Qualified',
    created: '25/10/2026',
    owner: 'Jonathan Cross FRICS',
    estimatedValue: '£3,500.00',
    notes: 'Boundary dispute litigation, required for Central London County Court hearing.',
  },
  {
    id: 'LD-1042',
    customerName: 'Matthew Taylor',
    customerEmail: 'm.taylor@guildfordpm.com',
    customerPhone: '+44 7700 900384',
    enquiry: 'RICS Level 2 Home Survey',
    property: '84 Epsom Road',
    location: 'Guildford, Surrey GU1 2PF',
    source: 'Google Ads',
    status: 'New',
    created: '24/10/2026',
    owner: 'Sarah Jenkins',
    estimatedValue: '£620.00',
    notes: '1930s semi-detached property, loft conversion completed in 2018.',
  },
  {
    id: 'LD-1041',
    customerName: 'Kensington Estates PLC',
    customerEmail: 'acquisitions@kensingtonestates.co.uk',
    customerPhone: '+44 20 7946 0841',
    enquiry: 'Full RICS Building Survey (Level 3)',
    property: '24 Kensington Palace Gardens',
    location: 'Kensington, London W8 4QQ',
    source: 'Partner',
    status: 'Converted',
    created: '24/10/2026',
    owner: 'David Thorne MRICS',
    estimatedValue: '£1,850.00',
    notes: 'Survey completed today, report drafting in progress.',
  },
  {
    id: 'LD-1040',
    customerName: 'Arthur Pendelton',
    customerEmail: 'pendelton@btinternet.com',
    customerPhone: '+44 7700 900677',
    enquiry: 'Residential Red Book Valuation',
    property: '107 Queenstown Road',
    location: 'Battersea, London SW8 3RH',
    source: 'Local Surveyors Direct',
    status: 'Lost',
    created: '23/10/2026',
    owner: 'Sarah Jenkins',
    estimatedValue: '£550.00',
    notes: 'Client decided to postpone purchase due to chain collapse.',
  },
  {
    id: 'LD-1039',
    customerName: 'Gareth & Hannah Edwards',
    customerEmail: 'gareth.edwards@surbiton.co.uk',
    customerPhone: '+44 7700 900744',
    enquiry: 'RICS Level 2 Home Survey',
    property: '82 St Andrews Road',
    location: 'Surbiton, Surrey KT6 4DX',
    source: 'Website',
    status: 'Contacted',
    created: '23/10/2026',
    owner: 'Alexander Sterling',
    estimatedValue: '£620.00',
    notes: 'Sent quote via email, left voicemail regarding surveyor dates.',
  },
  {
    id: 'LD-1038',
    customerName: 'Richmond Borough Properties',
    customerEmail: 'estates@richmondborough.org.uk',
    customerPhone: '+44 20 8940 1289',
    enquiry: 'Specific Defect Investigation',
    property: '8 Chichester Road',
    location: 'Richmond, Surrey TW10 6RF',
    source: 'Referral',
    status: 'Converted',
    created: '22/10/2026',
    owner: 'David Thorne MRICS',
    estimatedValue: '£920.00',
    notes: 'Defect schedule delivered, fee settled in full.',
  },
  {
    id: 'LD-1037',
    customerName: 'Julian Blackwood QC',
    customerEmail: 'j.blackwood@innslaw.co.uk',
    customerPhone: '+44 7700 900812',
    enquiry: 'Dilapidations Dispute & Expert Witness',
    property: '14 Chancery Lane',
    location: 'Holborn, London WC2A 1LF',
    source: 'Expert Witness form',
    status: 'Quoted',
    created: '22/10/2026',
    owner: 'Jonathan Cross FRICS',
    estimatedValue: '£4,200.00',
    notes: 'Commercial lease termination dispute, quote valid for 14 days.',
  },
  {
    id: 'LD-1036',
    customerName: 'Samantha Ross',
    customerEmail: 's.ross@rossdesign.co.uk',
    customerPhone: '+44 7700 900988',
    enquiry: 'Level 2 Survey & Valuation',
    property: '3 Victoria Terrace',
    location: 'Weybridge, Surrey KT13 8DE',
    source: 'Google Ads',
    status: 'Contacted',
    created: '21/10/2026',
    owner: 'Sarah Jenkins',
    estimatedValue: '£680.00',
    notes: 'Client comparing quotes, offered £25 discount for prompt booking.',
  },
  {
    id: 'LD-1035',
    customerName: 'Apex Asset Holdings Ltd',
    customerEmail: 'investments@apexasset.com',
    customerPhone: '+44 20 7946 0773',
    enquiry: 'Commercial Portfolio Valuation (4 Units)',
    property: '42 Belgrave Square',
    location: 'Belgravia, London SW1X 8NT',
    source: 'Partner',
    status: 'Converted',
    created: '20/10/2026',
    owner: 'Alexander Sterling',
    estimatedValue: '£3,200.00',
    notes: 'Portfolio inspected, report signed off.',
  },
  {
    id: 'LD-1034',
    customerName: 'Nigel Farringdon',
    customerEmail: 'n.farringdon@chelseapm.com',
    customerPhone: '+44 7700 900455',
    enquiry: 'Level 3 Full Structural Survey',
    property: '71 Kings Road',
    location: 'Chelsea, London SW3 4NT',
    source: 'Local Surveyors Direct',
    status: 'Lost',
    created: '19/10/2026',
    owner: 'Sarah Jenkins',
    estimatedValue: '£1,650.00',
    notes: 'Instructed alternative local surveyor who could attend next day.',
  },
];

const LEADS_STORAGE_KEY = 'propertygroup_crm_leads_v1';

export const getStoredLeads = () => {
  try {
    const raw = localStorage.getItem(LEADS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (e) {
    console.error('Failed reading leads from storage', e);
  }
  return INITIAL_LEADS;
};

export const saveStoredLeads = (leads) => {
  try {
    localStorage.setItem(LEADS_STORAGE_KEY, JSON.stringify(leads));
    window.dispatchEvent(new Event('propertygroup_leads_updated'));
  } catch (e) {
    console.error('Failed saving leads to storage', e);
  }
};

export const useLeads = () => {
  const [leads, setLeadsState] = useState(getStoredLeads);

  useEffect(() => {
    const onUpdate = () => {
      setLeadsState(getStoredLeads());
    };
    window.addEventListener('propertygroup_leads_updated', onUpdate);
    window.addEventListener('storage', onUpdate);
    return () => {
      window.removeEventListener('propertygroup_leads_updated', onUpdate);
      window.removeEventListener('storage', onUpdate);
    };
  }, []);

  const setLeads = (updater) => {
    setLeadsState((prev) => {
      const next = typeof updater === 'function' ? updater(prev) : updater;
      saveStoredLeads(next);
      return next;
    });
  };

  const updateLeadStatus = (leadId, newStatus, extraData = {}) => {
    setLeads((prev) =>
      prev.map((l) => {
        if (l.id !== leadId) return l;
        return {
          ...l,
          status: newStatus,
          ...extraData,
        };
      })
    );
  };

  const addLead = (newLead) => {
    setLeads((prev) => [newLead, ...prev]);
  };

  const deleteLead = (leadId) => {
    setLeads((prev) => prev.filter((l) => l.id !== leadId));
  };

  return { leads, setLeads, updateLeadStatus, addLead, deleteLead };
};

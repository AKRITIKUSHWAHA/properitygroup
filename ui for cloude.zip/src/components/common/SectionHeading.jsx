export { SectionHeading } from './CommonUI';


import React from 'react';
import { Scale, ShieldCheck, CheckCircle2, FileText, Users, ArrowRight, Gavel, HelpCircle, Phone, Mail, Building } from 'lucide-react';
import { expertWitnessService } from '../../config/services';
import { siteConfig } from '../../config/siteConfig';
import { useDocumentTitle } from '../../hooks/useDocumentTitle';
import { Container } from '../../components/common/Container';
import { Breadcrumbs } from '../../components/common/Breadcrumbs';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { ExpertWitnessForm } from '../../components/forms/ExpertWitnessForm';

export function ExpertWitnessPage() {
  useDocumentTitle(
    expertWitnessService.meta.title,
    expertWitnessService.meta.description
  );

  const breadcrumbs = [
    { label: "Legal & Disputes", path: "/expert-witness" },
    { label: "Expert Witness", path: "/expert-witness" }
  ];

  return (
    <div className="expert-witness-page service-page luxury-site-canvas">
      {/* High-Impact Architectural Header Banner */}
      <header
        className="service-header-hero"
        style={{ backgroundImage: `url(${expertWitnessService.imageUrl})` }}
      >
        <div className="service-header-overlay" />
        <Container>
          <div className="service-header-content">
            <Breadcrumbs items={breadcrumbs} />
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem', marginBottom: 'var(--space-2)' }}>
              <Badge variant="gold">Civil Litigation Practice</Badge>
              <span style={{ fontSize: 'var(--font-size-xs)', color: '#CBD5E1', fontWeight: 600 }}>
                {expertWitnessService.cprCompliance}
              </span>
            </div>
            <h1 className="page-header-title">{expertWitnessService.name}</h1>
            <p className="page-header-desc">{expertWitnessService.tagline}</p>

            {/* Service Metadata Strip */}
            <div className="service-meta-strip">
              <span className="service-meta-pill">
                <Scale size={14} className="text-white" />
                <span>Civil Procedure Rules (CPR) Part 35</span>
              </span>
              <span className="service-meta-pill">
                <ShieldCheck size={14} className="text-white" />
                <span>Overriding Duty to the Court</span>
              </span>
              <span className="service-meta-pill">
                <Building size={14} className="text-white" />
                <span>Scott Schedules &amp; Quantum Diagnostics</span>
              </span>
              <span className="service-meta-pill">
                <Phone size={14} className="text-white" />
                <span>Solicitor &amp; Direct Litigation Instructions</span>
              </span>
            </div>
          </div>
        </Container>
      </header>

      {/* Main Section */}
      <section className="section">
        <Container>
          <div className="expert-detail-grid">
            {/* Left Column: Legal Context & Scope */}
            <div>
              {/* Introduction */}
              <div style={{ marginBottom: 'var(--space-8)' }}>
                <h2 style={{ color: '#FFFFFF', marginBottom: '1rem', fontWeight: 700 }}>Independent Technical Evidence for Property Disputes</h2>
                <p style={{ fontSize: 'var(--font-size-md)', lineHeight: '1.7', color: '#F8FAFC' }}>
                  When contentious property disputes escalate to formal litigation, arbitration, or pre-action dispute resolution, courts and tribunals require impartial, objective technical evidence. As independent expert surveyors, our duty in expert witness matters is defined by Civil Procedure Rules (CPR) Part 35: our overriding duty is to the Court, rather than to the instructing client.
                </p>
                <p style={{ lineHeight: '1.7', color: '#CBD5E1' }}>
                  We provide CPR Part 35 compliant expert reports, advisory technical audits, Scott Schedule contributions, joint expert meetings, and oral testimony at hearings across London, Surrey, Oxfordshire, Buckinghamshire, and Berkshire.
                </p>
              </div>

              {/* Target Audiences (Master Spec Part 7 Item 4) */}
              <div style={{ marginBottom: 'var(--space-8)' }}>
                <h3 style={{ marginBottom: 'var(--space-4)', color: '#FFFFFF' }}>
                  Intended Audiences &amp; Instructing Parties
                </h3>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: 'var(--space-3)' }}>
                  {expertWitnessService.targetAudiences.map((aud, idx) => (
                    <div
                      key={idx}
                      className="expert-audience-card"
                      style={{
                        padding: 'var(--space-4)',
                        borderRadius: 'var(--radius-md)',
                        border: '1px solid #CBD5E1',
                        backgroundColor: '#FFFFFF',
                        boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04)'
                      }}
                    >
                      <h4 style={{ fontSize: 'var(--font-size-sm)', color: '#0F172A', fontWeight: 700, marginBottom: '0.25rem' }}>
                        {aud.title}
                      </h4>
                      <p style={{ fontSize: 'var(--font-size-xs)', color: '#334155', fontWeight: 500, margin: 0, lineHeight: 1.55 }}>
                        {aud.description}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Dispute Categories Covered */}
              <div style={{ marginBottom: 'var(--space-8)' }}>
                <h3 style={{ marginBottom: 'var(--space-3)', color: '#FFFFFF' }}>
                  Dispute Disciplines &amp; Case Typologies
                </h3>
                <ul style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', fontSize: 'var(--font-size-sm)' }}>
                  {expertWitnessService.disputeCategories.map((item, idx) => (
                    <li key={idx} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <Scale size={16} style={{ color: 'var(--color-accent-gold)', flexShrink: 0 }} />
                      <span style={{ color: '#E2E8F0', fontWeight: 500 }}>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* 5-Step Instruction Process (Master Spec Part 7 Item 3) */}
              <div className="expert-process-card" style={{ marginBottom: 'var(--space-8)', padding: 'var(--space-6)', backgroundColor: '#FFFFFF', border: '1px solid #CBD5E1', borderRadius: 'var(--radius-lg)', boxShadow: '0 4px 16px rgba(0, 0, 0, 0.05)' }}>
                <h3 style={{ marginBottom: 'var(--space-4)', color: '#0F172A', fontWeight: 700 }}>
                  The Expert Witness Instruction Process
                </h3>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
                  {expertWitnessService.instructionProcess.map(step => (
                    <div key={step.step} style={{ display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                      <div
                        className="step-number-badge"
                        style={{
                          width: '28px',
                          height: '28px',
                          borderRadius: '50%',
                          backgroundColor: '#142A43',
                          color: '#FFFFFF',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: 'var(--font-size-xs)',
                          fontWeight: 'bold',
                          flexShrink: 0
                        }}
                      >
                        {step.step}
                      </div>
                      <div>
                        <h4 style={{ fontSize: 'var(--font-size-sm)', color: '#0F172A', fontWeight: 700, marginBottom: '0.25rem' }}>
                          {step.title}
                        </h4>
                        <p style={{ fontSize: 'var(--font-size-xs)', color: '#334155', fontWeight: 500, margin: 0, lineHeight: 1.55 }}>
                          {step.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Professional Credentials & Transparency Safeguard (Master Spec Part 7 Item 2) */}
              <div className="expert-credentials-notice" style={{ padding: 'var(--space-5)', backgroundColor: '#FFFFFF', borderRadius: 'var(--radius-md)', border: '1px solid #CBD5E1', boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04)' }}>
                <h4 style={{ color: '#0F172A', display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: 'var(--space-2)', fontWeight: 700 }}>
                  <ShieldCheck size={18} style={{ color: '#142A43' }} />
                  <span style={{ color: '#0F172A' }}>Professional Credentials Notice</span>
                </h4>
                <p style={{ fontSize: 'var(--font-size-xs)', color: '#334155', lineHeight: '1.6', fontWeight: 500, margin: 0 }}>
                  In accordance with professional rules, individual surveyor CVs, full statements of courtroom appearance experience, and practicing certificate numbers are confirmed upon formal instruction inquiry. No unverified legal appointments or court credentials are fabricated on this public website.
                </p>
              </div>
            </div>

            {/* Right Column: Separate Expert Witness Enquiry Form (Master Spec Part 7 Item 5) */}
            <div id="instruction" className="service-quote-sidebar">
              <ExpertWitnessForm />
            </div>
          </div>
        </Container>
      </section>

      {/* Direct Contact Banner */}
      <section className="section section-navy" aria-label="Legal Practice Contact">
        <Container isNarrow>
          <div style={{ textAlign: 'center' }}>
            <h2 style={{ color: 'var(--color-white)', marginBottom: 'var(--space-2)' }}>
              Urgent Court Deadlines or Pre-Action Inquiries?
            </h2>
            <p style={{ color: 'var(--color-silver-light)', fontSize: 'var(--font-size-sm)', marginBottom: 'var(--space-6)' }}>
              Contact our legal instruction coordinator directly for immediate conflict check verification and instruction availability.
            </p>
            <div style={{ display: 'flex', justifyContent: 'center', gap: '1.5rem', flexWrap: 'wrap', fontSize: 'var(--font-size-sm)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Phone size={16} style={{ color: '#FFFFFF' }} />
                <a href={`tel:${siteConfig.contact.telephone}`} style={{ color: 'var(--color-white)', fontWeight: 'bold' }}>
                  {siteConfig.contact.telephoneDisplay}
                </a>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Mail size={16} style={{ color: '#FFFFFF' }} />
                <span style={{ color: 'var(--color-white)' }}>{siteConfig.contact.email}</span>
              </div>
            </div>
          </div>
        </Container>
      </section>
    </div>
  );
}

